The Flask backend serves the complete HTML/CSS/JavaScript frontend. This folder is reserved for future standalone frontend assets.
