The frontend is served by Flask from backend/templates and backend/static. Open http://127.0.0.1:5000 after starting the backend.
